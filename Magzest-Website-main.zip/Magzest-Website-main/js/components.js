/* =========================================================
   Magzest — Shared page chrome (header, footer, booking
   modal, cookie consent).

   Loaded as a plain <script src>, not fetch() — fetching a
   local partial fails under file:// (CORS), but a classic
   script tag loads fine. Each page keeps a small placeholder
   element (#site-header, #site-footer, #site-booking-modal,
   #site-cookie-consent) at the spot the real markup used to
   live; this script replaces each placeholder with real
   markup via outerHTML the moment it runs.

   Load order matters: this file must be included AFTER all
   four placeholders exist in the DOM and BEFORE js/main.js,
   so main.js's element lookups (#navbar, #mobile-menu-toggle,
   #booking-form, .newsletter-form, #cookie-consent, ...) find
   real elements instead of nothing.
   ========================================================= */

(function () {
  "use strict";

  const NAV_LINKS = [
    ["index.html", "Home"],
    ["about.html", "About"],
    ["services.html", "Services"],
    ["portfolio.html", "Portfolio"],
    ["careers.html", "Careers"],
    ["blog.html", "Blog"],
    ["vlogs.html", "Vlogs"],
    ["contact.html", "Contact"],
  ];

  function currentPage() {
    const file = window.location.pathname.split("/").pop();
    return file || "index.html";
  }

  // Blog articles (blog-*.html) keep the "Blog" nav link highlighted.
  function isActive(href, page) {
    return href === page || (href === "blog.html" && page.startsWith("blog-"));
  }

  function headerHTML() {
    const page = currentPage();

    const desktopLinks = NAV_LINKS.map(([href, label]) => {
      const active = isActive(href, page);
      const cls = "nav-link" + (active ? " active" : "");
      return `<a href="${href}" class="${cls}"${active ? ' aria-current="page"' : ""}>${label}</a>`;
    }).join("\n      ");

    const mobileLinks = NAV_LINKS.map(([href, label]) => {
      const active = isActive(href, page);
      const cls = "flex items-center justify-between rounded-md px-3 py-3 text-base " +
        (active ? "bg-slate-100 text-blue-900 font-semibold" : "text-slate-700 hover:bg-slate-50");
      return `<a href="${href}" class="${cls}"${active ? ' aria-current="page"' : ""}>${label}<i data-lucide="chevron-right" class="w-4 h-4 text-slate-400"></i></a>`;
    }).join("\n    ");

    return `<header id="navbar" class="navbar-glass fixed top-0 inset-x-0 z-40">
  <nav class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-[76px]">
    <a href="index.html" class="flex items-center gap-2 font-heading font-extrabold text-2xl uppercase tracking-tight logo-word">
      Magzest
    </a>
    <div class="hidden lg:flex items-center gap-8 text-sm font-medium text-slate-600">
      ${desktopLinks}
    </div>
    <div class="flex items-center gap-3">
      <button data-open-booking class="hidden md:inline-flex btn-glow bg-blue-900 hover:bg-blue-950 text-white text-sm font-semibold px-5 py-2.5 rounded-md">Request a Consultation</button>
      <button id="mobile-menu-toggle" aria-label="Open menu" aria-expanded="false" aria-controls="mobile-menu" class="lg:hidden w-11 h-11 -mr-2 flex items-center justify-center rounded-md hover:bg-slate-100">
        <i data-lucide="menu" data-menu-icon class="w-6 h-6"></i>
      </button>
    </div>
  </nav>
  <div id="mobile-menu" class="hidden lg:hidden flex-col gap-0.5 px-4 pb-5 pt-1 bg-white border-t border-slate-100 shadow-lg max-h-[calc(100dvh-76px)] overflow-y-auto">
    ${mobileLinks}
    <button data-open-booking class="btn-glow mt-3 w-full inline-flex items-center justify-center gap-2 bg-blue-900 hover:bg-blue-950 text-white font-semibold px-5 py-3 rounded-md"><i data-lucide="calendar-clock" class="w-4 h-4"></i> Request a Consultation</button>
    <a href="tel:+918919901489" class="mt-2 w-full inline-flex items-center justify-center gap-2 border border-slate-200 text-slate-700 font-medium px-5 py-3 rounded-md hover:bg-slate-50"><i data-lucide="phone" class="w-4 h-4"></i> Call +91 89199 01489</a>
  </div>
</header>`;
  }

  function footerHTML() {
    return `<footer class="bg-blue-950 text-slate-300 pt-16 pb-8">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid sm:grid-cols-2 lg:grid-cols-4 gap-10">
    <div>
      <a href="index.html" class="flex items-center gap-2 font-heading font-extrabold text-2xl uppercase tracking-tight text-white">
        Magzest
      </a>
      <p class="mt-4 text-sm text-slate-400">Full-service IT company building websites, apps, growth marketing and tech talent pipelines for ambitious businesses.</p>
      <div class="flex gap-3 mt-5">
        <a href="https://www.linkedin.com/company/magzest-india/" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn" class="w-9 h-9 rounded-full bg-slate-800 hover:bg-white hover:text-black flex items-center justify-center transition"><svg class="w-4 h-4" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg></a>
        <a href="https://www.instagram.com/magzest" target="_blank" rel="noopener noreferrer" aria-label="Instagram" class="w-9 h-9 rounded-full bg-slate-800 hover:bg-white hover:text-black flex items-center justify-center transition"><svg class="w-4 h-4" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.98-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.198-4.354-2.618-6.78-6.98-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg></a>
      </div>
    </div>
    <div>
      <h4 class="font-heading font-semibold text-white mb-4">Company</h4>
      <ul class="space-y-1 text-sm">
        <li><a href="about.html" class="inline-block py-1 hover:text-white transition">About Us</a></li>
        <li><a href="portfolio.html" class="inline-block py-1 hover:text-white transition">Portfolio</a></li>
        <li><a href="ideas.html" class="inline-block py-1 hover:text-white transition">Business Ideas</a></li>
        <li><a href="careers.html" class="inline-block py-1 hover:text-white transition">Careers</a></li>
        <li><a href="blog.html" class="inline-block py-1 hover:text-white transition">Blog</a></li>
        <li><a href="vlogs.html" class="inline-block py-1 hover:text-white transition">Vlogs</a></li>
        <li><a href="contact.html" class="inline-block py-1 hover:text-white transition">Contact</a></li>
      </ul>
    </div>
    <div>
      <h4 class="font-heading font-semibold text-white mb-4">Services</h4>
      <ul class="space-y-1 text-sm">
        <li><a href="website-development-company-hyderabad.html" class="inline-block py-1 hover:text-white transition">Website Development</a></li>
        <li><a href="mobile-app-development-company-hyderabad.html" class="inline-block py-1 hover:text-white transition">Mobile App Development</a></li>
        <li><a href="it-services-company-hyderabad.html" class="inline-block py-1 hover:text-white transition">IT Services &amp; Consulting</a></li>
        <li><a href="digital-marketing-agency-hyderabad.html" class="inline-block py-1 hover:text-white transition">Digital Marketing &amp; SEO</a></li>
        <li><a href="telecom-services-hyderabad.html" class="inline-block py-1 hover:text-white transition">Telecom Services</a></li>
        <li><a href="it-recruitment-agency-hyderabad.html" class="inline-block py-1 hover:text-white transition">IT &amp; Telecom Recruitment</a></li>
      </ul>
    </div>
    <div>
      <h4 class="font-heading font-semibold text-white mb-4">Stay updated</h4>
      <p class="text-sm text-slate-400 mb-3">Subscribe for tech trends &amp; company news.</p>
      <form class="newsletter-form flex gap-2" novalidate>
        <input type="text" name="_honey" style="display:none" tabindex="-1" autocomplete="off" />
        <input type="email" name="email" required placeholder="Your email" class="min-w-0 flex-1 rounded-md px-4 py-2.5 text-sm bg-slate-900 border border-slate-700 focus:outline-none focus:border-white text-white placeholder:text-slate-500" />
        <button class="btn-glow bg-white hover:bg-slate-200 text-black w-11 h-11 flex-shrink-0 rounded-md flex items-center justify-center"><i data-lucide="send" class="w-4 h-4"></i></button>
      </form>
      <a href="mailto:contact@magzest.tech" class="text-sm text-slate-300 hover:text-white mt-5 py-1 flex items-center gap-2 transition"><i data-lucide="mail" class="w-4 h-4"></i> contact@magzest.tech</a>
      <a href="tel:+918919901489" class="text-sm text-slate-300 hover:text-white mt-1 py-1 flex items-center gap-2 transition"><i data-lucide="phone" class="w-4 h-4"></i> +91 89199 01489</a>
    </div>
  </div>
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border-t border-slate-800 mt-12 pt-6 flex flex-wrap justify-between gap-4 text-sm text-slate-400">
    <p>&copy; <span data-year></span> Magzest Consultancy Services. All rights reserved.</p>
    <div class="flex flex-wrap gap-x-6 gap-y-1"><a href="privacy-policy.html" class="py-1 hover:text-white transition">Privacy Policy</a><a href="terms-of-service.html" class="py-1 hover:text-white transition">Terms of Service</a><a href="cookie-policy.html" class="py-1 hover:text-white transition">Cookie Policy</a></div>
  </div>
</footer>
`;
  }

  function bookingModalHTML() {
    return `<div id="booking-modal" role="dialog" aria-modal="true" aria-labelledby="booking-title" aria-hidden="true" class="modal-overlay hidden-state fixed inset-0 z-[70] bg-black/60 flex items-center justify-center p-4">
  <div class="popup-card relative glass-card bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 sm:p-8 max-h-[calc(100dvh-2rem)] overflow-y-auto">
    <button data-close-booking aria-label="Close" class="absolute top-3 right-3 w-10 h-10 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition"><i data-lucide="x" class="w-5 h-5"></i></button>
    <div class="w-14 h-14 rounded-md bg-blue-900 text-white flex items-center justify-center mb-4"><i data-lucide="calendar-clock" class="w-7 h-7"></i></div>
    <h3 id="booking-title" class="font-heading text-xl font-bold">Request a free consultation</h3>
    <p class="text-sm text-slate-500 mt-1">Share your details and we'll get back to you within one business day.</p>
    <form id="booking-form" class="mt-5 space-y-3" novalidate>
      <input type="text" name="_honey" style="display:none" tabindex="-1" autocomplete="off" />
      <input type="hidden" name="source" value="Consultation request" />
      <div class="grid grid-cols-2 gap-3">
        <div><input type="text" name="first_name" maxlength="40" autocomplete="given-name" aria-label="First name" placeholder="First name" class="w-full rounded-md px-4 py-3 text-sm bg-slate-100 border border-transparent focus:outline-none focus:border-blue-600" /></div>
        <div><input type="text" name="last_name" required maxlength="80" autocomplete="family-name" aria-label="Last name" placeholder="Last name" class="w-full rounded-md px-4 py-3 text-sm bg-slate-100 border border-transparent focus:outline-none focus:border-blue-600" /></div>
      </div>
      <input type="email" name="email" maxlength="100" autocomplete="email" aria-label="Email address" placeholder="Email address" class="w-full rounded-md px-4 py-3 text-sm bg-slate-100 border border-transparent focus:outline-none focus:border-blue-600" />
      <input type="tel" name="phone" maxlength="30" autocomplete="tel" aria-label="Mobile" placeholder="Mobile" class="w-full rounded-md px-4 py-3 text-sm bg-slate-100 border border-transparent focus:outline-none focus:border-blue-600" />
      <div class="grid grid-cols-2 gap-3">
        <div><input type="text" name="city" maxlength="100" autocomplete="address-level2" aria-label="City" placeholder="City" class="w-full rounded-md px-4 py-3 text-sm bg-slate-100 border border-transparent focus:outline-none focus:border-blue-600" /></div>
        <div><input type="text" name="state" maxlength="100" autocomplete="address-level1" aria-label="State" placeholder="State" class="w-full rounded-md px-4 py-3 text-sm bg-slate-100 border border-transparent focus:outline-none focus:border-blue-600" /></div>
      </div>
      <textarea name="message" rows="3" aria-label="Message" placeholder="Tell us about your project or goals…" class="w-full rounded-md px-4 py-3 text-sm bg-slate-100 border border-transparent focus:outline-none focus:border-blue-600"></textarea>
      <button type="submit" class="btn-glow w-full bg-blue-900 hover:bg-blue-950 text-white font-semibold px-6 py-3 rounded-md"><span id="booking-submit-label">Request Consultation</span></button>
    </form>
    <div id="booking-success" class="hidden text-center py-6">
      <div class="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto mb-4"><i data-lucide="check" class="w-7 h-7"></i></div>
      <h4 class="font-heading text-lg font-bold">Request received!</h4>
      <p class="text-sm text-slate-500 mt-2">Thanks — a Magzest team member will get back to you within one business day.</p>
    </div>
  </div>
</div>`;
  }

  function cookieConsentHTML() {
    return `<div id="cookie-consent" role="region" aria-label="Cookie notice" class="fixed z-[80] bottom-3 inset-x-3 sm:inset-x-auto sm:left-6 sm:bottom-6 sm:max-w-md rounded-xl border border-white/10 bg-black/95 backdrop-blur text-slate-200 shadow-2xl px-4 py-3 sm:px-5 sm:py-4 flex items-center gap-4">
  <p class="text-[13px] leading-snug sm:text-sm">One essential cookie from us; our Zoho live chat sets its own. No ad cookies. <a href="cookie-policy.html" class="underline hover:text-white">Cookie Policy</a></p>
  <button data-cookie-choice="acknowledged" class="btn-glow flex-shrink-0 px-4 py-2.5 rounded-md text-sm bg-white hover:bg-slate-200 text-black font-semibold">OK, got it</button>
</div>`;
  }

  function inject(placeholderId, html) {
    const el = document.getElementById(placeholderId);
    if (el) el.outerHTML = html;
  }

  inject("site-header", headerHTML());
  inject("site-footer", footerHTML());
  inject("site-booking-modal", bookingModalHTML());
  inject("site-cookie-consent", cookieConsentHTML());
})();
